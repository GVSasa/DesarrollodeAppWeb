package mx.tec.web.lab.vo;

import java.util.List;

public class Product {

	private String id;
	public String getId() {
		return id;
	}
	public Product(String id, String name, String desription, List<Sku> childSkus) {
		super();
		this.id = id;
		this.name = name;
		this.desription = desription;
		this.childSkus = childSkus;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	private String name;
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the desription
	 */
	public String getDesription() {
		return desription;
	}
	/**
	 * @param desription the desription to set
	 */
	public void setDesription(String desription) {
		this.desription = desription;
	}
	/**
	 * @return the childSkus
	 */
	public List<Sku> getChildSkus() {
		return childSkus;
	}
	/**
	 * @param childSkus the childSkus to set
	 */
	public void setChildSkus(List<Sku> childSkus) {
		this.childSkus = childSkus;
	}

	private String desription;
	private List<Sku> childSkus;

}
