package mx.tec.web.lab.vo;

public class Sku {

	public Sku(String id, String color, String size, double listPrice, double salePrice, long quantityOnHand) {
		super();
		this.id = id;
		this.color = color;
		this.size = size;
		this.listPrice = listPrice;
		this.salePrice = salePrice;
		this.quantityOnHand = quantityOnHand;
		this.smallImg = smallImg;
		this.mediumImg = mediumImg;
		this.bigImg = bigImg;
		
	}
	public Sku(String id2, String color2, String size2, double listPrice2, double salePrice2, int quantityOnHand2) {
		// TODO Auto-generated constructor stub
	}
	
	private	String id;
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the color
	 */
	public String getColor() {
		return color;
	}
	/**
	 * @param color the color to set
	 */
	public void setColor(String color) {
		this.color = color;
	}
	/**
	 * @return the size
	 */
	public String getSize() {
		return size;
	}
	/**
	 * @param size the size to set
	 */
	public void setSize(String size) {
		this.size = size;
	}
	/**
	 * @return the listPrice
	 */
	public double getListPrice() {
		return listPrice;
	}
	/**
	 * @param listPrice the listPrice to set
	 */
	public void setListPrice(double listPrice) {
		this.listPrice = listPrice;
	}
	/**
	 * @return the salePrice
	 */
	public double getSalePrice() {
		return salePrice;
	}
	/**
	 * @param salePrice the salePrice to set
	 */
	public void setSalePrice(double salePrice) {
		this.salePrice = salePrice;
	}
	/**
	 * @return the quantityOnHand
	 */
	public long getQuantityOnHand() {
		return quantityOnHand;
	}
	/**
	 * @param quantityOnHand the quantityOnHand to set
	 */
	public void setQuantityOnHand(long quantityOnHand) {
		this.quantityOnHand = quantityOnHand;
	}

	private	String color;
	private	String size;
	private	double listPrice;
	private	double salePrice;
	private	long quantityOnHand;
	/**
	 * @return the smallImg
	 */
	public String getSmallImg() {
		return smallImg;
	}
	/**
	 * @param smallImg the smallImg to set
	 */
	public void setSmallImg(String smallImg) {
		this.smallImg = smallImg;
	}
	/**
	 * @return the mediumImg
	 */
	public String getMediumImg() {
		return mediumImg;
	}
	/**
	 * @param mediumImg the mediumImg to set
	 */
	public void setMediumImg(String mediumImg) {
		this.mediumImg = mediumImg;
	}
	/**
	 * @return the bigImg
	 */
	public String getBigImg() {
		return bigImg;
	}
	/**
	 * @param bigImg the bigImg to set
	 */
	public void setBigImg(String bigImg) {
		this.bigImg = bigImg;
	}
	private String smallImg;
	private String mediumImg;
	private String bigImg;
	
	
	
}
